# TFmini-Plus-LiDAR-interfacing-with-Raspberry-Pi
Python code for using serial hardware port of Raspberry Pi
