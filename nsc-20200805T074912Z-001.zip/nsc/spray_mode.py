from enum import IntEnum

class SprayMode(IntEnum):
    AUTO = 1
    DETECT = 2
    MANUAL = 3