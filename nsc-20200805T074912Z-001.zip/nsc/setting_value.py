from spray_mode import *
class ConfigValue:
    spray_mode = SprayMode.MANUAL